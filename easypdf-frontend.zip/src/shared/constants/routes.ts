export const ROUTES = {
  home: '/',
  convert: '/convert',
} as const;
