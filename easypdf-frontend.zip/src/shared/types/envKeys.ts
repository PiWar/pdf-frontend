export type EnvKeys = 'API_URI';
