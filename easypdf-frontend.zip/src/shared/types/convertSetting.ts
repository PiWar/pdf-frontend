export type ConvertSetting = {
  available_extensions: string[];
  available_mime_types: string[];
  extension: string;
  context: string[];
};
