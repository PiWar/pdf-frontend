export type ConvertInfo = {
  icon?: string;
  title: string;
  description: string;
};
