'use server';
import { apiService } from '@/services/apiService';

export const convertFiles = async (formData: FormData) => {
  return await apiService.sendFiles(formData);
};
