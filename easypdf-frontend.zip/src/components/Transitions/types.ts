import { PropsWithChildren } from 'react';

export type TransitionProps = PropsWithChildren<{
  className?: string;
}>;
