'use client';

import { ConvertInfo } from '@/shared/types/convertInfo';
import { ConvertSetting } from '@/shared/types/convertSetting';
import { useState } from 'react';

type ConvertFormProps = {
  convertInfo: ConvertInfo;
  convertSetting: ConvertSetting;
};

export const ConvertForm = ({
  convertSetting,
  convertInfo,
}: ConvertFormProps) => {
  const [hasFiles, setHasFiles] = useState(false);

  return hasFiles ? (
    <div>form</div>
  ) : (
    <div className='p-2 md:p-4'>
      <h1 className='mb-4 text-center text-xl font-medium lg:text-2xl'>
        {convertInfo.title}
      </h1>
      <p className='text-center text-neutral-700 lg:text-xl'>
        {convertInfo.description}
      </p>
    </div>
  );
};
