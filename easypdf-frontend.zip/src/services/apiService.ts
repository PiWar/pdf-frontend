import { api } from '@/api';
import { ConvertSetting } from '@/shared/types/convertSetting';

export const apiService = {
  getTypesSettings: async () => {
    return await api.get<Record<string, ConvertSetting>>({
      uri: 'process/types',
    });
  },

  sendFiles: async (data: FormData) => {
    return api.post<{
      uuid?: string;
    }>({
      uri: 'process/files',
      data,
    });
  },
} as const;
